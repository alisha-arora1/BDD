package com.cg.project.stepDefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GithubSignInStepDefination {
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setUpStepEnv(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\BDD Cucumber\\chromedriver.exe");
	}

	@Given("^User is on Github login Page$")
	public void user_is_on_Github_login_Page() throws Throwable {
	   driver=new ChromeDriver();
	   driver.get("https://github.com/login");
	   loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enters invalid username and password$")
	public void user_enters_invalid_username_and_password() throws Throwable {
	   loginPage.setUsername("alishaarora");
	   loginPage.setPassword("fffdddd");
	   loginPage.clickSignIn();
	}

	@Then("^'Incorrect username and password\\.' Message should display$")
	public void incorrect_username_and_password_Message_should_display() throws Throwable {
	   String expectedErrorMessage="Incorrect username or password.";
	   Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	   driver.close();
	}

	@When("^User enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		loginPage.setUsername("alisha-arora1");
		   loginPage.setPassword("Alisha_arora1");
		   loginPage.clickSignIn();
	}

	@Then("^user should successfully Signin on his Github Account$")
	public void user_should_successfully_Signin_on_his_Github_Account() throws Throwable {
	  String actualTitle=driver.getTitle();
	  String expectedTitle="alisha-arora1";
	  Assert.assertEquals(expectedTitle, actualTitle);
	  driver.close();
	}

}
