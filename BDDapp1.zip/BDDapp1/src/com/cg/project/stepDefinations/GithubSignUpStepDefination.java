package com.cg.project.stepDefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.RegisterPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubSignUpStepDefination {
	
	private WebDriver driver;
	private RegisterPage registerPage;

	@Before
	public void setUpStepEnv(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\BDD Cucumber\\chromedriver.exe");
	}

	@Given("^User is on Github Home Page$")
	public void user_is_on_Github_Home_Page() throws Throwable {
		 driver=new ChromeDriver();
		   driver.get("https://github.com/");
		   registerPage=PageFactory.initElements(driver, RegisterPage.class);
	}

	@When("^User enters invalid username or email or password$")
	public void user_enters_invalid_username_or_email_or_password() throws Throwable {
		 registerPage.setUsername("aaaaaaa");
		 registerPage.setEmail("alisha@gmail.com");
		 registerPage.setPassword("uuudddd");
		 registerPage.clickSignUp();
	}

	@Then("^'There were problems creating your account\\.' Message should display$")
	public void there_were_problems_creating_your_account_Message_should_display() throws Throwable {
		 String expectedErrorMessage="There were problems creating your account.";
		   Assert.assertEquals(expectedErrorMessage, registerPage.getActualErrorMessage());
		   driver.close();
	}

	@When("^User enters valid username or email or password$")
	public void user_enters_valid_username_or_email_or_password() throws Throwable {
		 registerPage.setUsername("Sally654");
		 registerPage.setEmail("seemayadav@gmail.com");
		 registerPage.setPassword("Seemayadav_12gh");
		 registerPage.clickSignUp();

	}

	@Then("^user should successfully Signup on Github$")
	public void user_should_successfully_Signup_on_Github() throws Throwable {
		String actualTitle=driver.getTitle();
		  String expectedTitle="Sally654";
		  Assert.assertEquals(expectedTitle, actualTitle);
		  driver.close();
	}
}
