package com.cg.github.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterPage {
	
	
	@FindBy(how=How.ID,id="user[login]")
	private WebElement username;
	

	@FindBy(how=How.ID,id="user[email]")
	private WebElement email;
	
	@FindBy(how=How.ID,id="user[password]")
	private WebElement password;
	
	@FindBy(className="btn-mktg")
	private WebElement button;
	
	@FindBy(how=How.XPATH,xpath="//div[@class='flash flash-error my-3']\"")    
	private WebElement actualErrorMessage;
	
	public RegisterPage(){}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);;
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);;
	}
	
	public String getActualErrorMessage()
	{
		return actualErrorMessage.getText();
	}
	
	public void clickSignUp()
	{
		button.click();
	}
	
	
	

}
